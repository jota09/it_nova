<?php

/**
 * Clase que controla los reporte
 * @author Euclides Rodriguez Gaitan
 *
 */
if (!defined('s3_entrada') || !s3_entrada) {
    die('No es un punto de entrada valido');
}

class S3Reporte {

    protected function realizarActualizaciones() {
        
    }

}