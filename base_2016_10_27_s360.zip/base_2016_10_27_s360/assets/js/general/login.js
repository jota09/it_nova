$(document).ready(function () {

   if ($("#tkn_cmb_pss").val() != "") {
      $("#cambiarContrasea").modal("show");
   }

   $("#btn_recuperar").click(function () {

      var email = $("#recuperar_correo").val();

      if ($.trim(email) == "" || $("#recuperar_correo").hasClass("invalid") || $("#btn_recuperar").hasClass("disabled")) {
         if ($.trim(email) == "") {
            $("#msgAlert").html("El Correo es obligatorio.");

         } else if ($("#recuperar_correo").hasClass("invalid") || $("#btn_recuperar").hasClass("disabled")) {
            $("#msgAlert").html("El Correo ingresado no es valido.");
         }
         $("#khazerAlert").modal("show");
      } else {

         //$('#Esperar').modal("show");
         $("#btn_recuperar").removeClass("waves-effect waves-light light-blue darken-4");
         $("#btn_recuperar").addClass("disabled");
         var datos = {
            'modulo': 'usuarios',
            'accion': 'Recuperar',
            email: email,
            ajax: true
         };

         $("#recordarcontrasea_esperar").removeClass("hidden");
         $.ajax({
            url: "index.php",
            data: datos,
            type: 'POST',
            dataType: 'json',
         }).done(function (result) {
            $("#recordarcontrasea_esperar").addClass("hidden");
            if (result == 1) {
               $("#msgAlert").html("Un corrreo fue enviado. \nPor favor, revisar su bandeja de correo.");
               $('#recordarcontrasea').modal("hide");
            } else {
               $("#msgAlert").html("No se encontro registro en nuestro sistema.<br />Por favor reviselo e intentelo de nuevo.");
            }
            $("#btn_recuperar").addClass("waves-effect waves-light light-blue darken-4");
            $("#btn_recuperar").removeClass("disabled");

            $("#khazerAlert").modal("show");
         });
      }
   });

   $("#btn_cambiar").click(function () {

      var pass = $("#cambiar_pass").val();
      var pass_pass = $("#cambiar_pass_pass").val();

      if ($.trim(pass) != "" && $.trim(pass_pass) != "") {
         if (pass !== pass_pass) {
            texto = "Las contraseñas son diferentes";

            $("#msgAlert").html(texto);
            $('#khazerAlert').modal("show");
            return false;
         }
         //$('#Esperar').modal('show');
         $("#btn_cambiar").removeClass("waves-effect waves-light light-blue darken-4");
         $("#btn_cambiar").addClass("disabled");
         var datos = {
            'modulo': 'usuarios',
            'accion': 'cambiarContrasenia',
            pass1: pass,
            pass2: pass_pass,
            tkn: $("#tkn_cmb_pss").val(),
            ajax: true
         };


         $.ajax({
            url: "index.php",
            data: datos,
            type: 'POST',
            dataType: 'json',
         }).done(function (result) {
            if (result == 1) {
               texto = "Su contraseña ha sido cambia exitosamente.";
            } else {
               texto = "Hubo un problema, en el proceso de actualización. Por favor intentelo más tarde.";
            }

            $("#msgAlert").html(texto);
            $('#khazerAlert').modal("show");
            //$('#Esperar').modal('hide');
            $("#btn_cambiar").addClass("waves-effect waves-light light-blue darken-4");
            $("#btn_cambiar").removeClass("disabled");
            $('#cambiarcontrasea').modal("hide");

         });



      }
   });
//   console.log(parseInt($("#error_login").val()));
   if (parseInt($("#error_login").val()) === 1) {
      texto = "Usuario o Contraseña equivocada. Por favor corregir, e intentar de nuevo. <br />Si el error persiste contacte al administrador. ";
      $("#msgAlert").html(texto);

      $('#khazerAlert').modal("show");
   }
});



