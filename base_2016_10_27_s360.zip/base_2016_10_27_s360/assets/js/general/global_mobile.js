$(document).ready(function () {
    $('select').select2('destroy');  } );